from aip import AipSpeech

""" 你的 APPID AK SK """
APP_ID = '34493829'
API_KEY = 'UrTKKniXTCfXc5Pf7k4RiqeG'
SECRET_KEY = 'zQnsqCAqorLx8x2PPDhGVrZqLAoY058Y'

client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

import os
import sys
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from aip import AipSpeech
from tkinter import filedialog

import urllib, hashlib
import random
import requests, sys



class play:
    def __init__(self):
        self.root = tk.Tk()  # 初始化窗口
        self.root.iconphoto(False, tk.PhotoImage(file='you.png'))
        self.root.title("实时文本转译系统")  # 窗口名称
        self.root.geometry("1600x900")  # 设置窗口大小
        self.root.resizable(width=True, height=True)  # 设置窗口是否可变,宽不可变,高可变,默认为True
        self.lb = tk.Label(self.root, text='请选择语音类型')  # 标签
        self.tt = tk.Text(self.root, width=219, height=30)  # 多行文本框
        self.tt_tr = tk.Text(self.root, width=219, height=30)  # 多行文本框
        self.in_text = self.tt
        self.cb = ttk.Combobox(self.root, width=12)  # 下拉列表框
        # 设置下拉列表框的内容
        self.cb['values'] = ('----请选择----', '甜美型', '萝莉型', '大叔型', '精神小伙型', '度逍遥', '度丫丫', '度小娇', '度米朵', '度博文', '度小童',
                             '度小萌')
        self.cb.current(0)  # 将当前选择状态置为0,也就是第一项
        self.cb.bind("<<ComboboxSelected>>", self.go)  # 绑定go函数，然后触发事件
        self.lb1 = tk.Label(self.root, text='请输入文件名：')
        self.e = tk.Entry(self.root, width=148, show=None, font=('Arial', 12))  # 文本框
        self.b1 = tk.Button(self.root, text='生成音频文件', width=10, height=1, command=self.sc)  # 按钮
        self.b2 = tk.Button(self.root, text='导入文本文件', width=10, height=1, command=self.select_file)  # 按钮
        self.b3 = tk.Button(self.root, text='转译', width=10, height=1, command=self.translation)  # 按钮

        # 各个组件的位置
        self.b3.place(x=1400, y=29)
        self.b2.place(x=1488, y=29)
        self.b1.place(x=1488, y=485)
        self.lb.place(x=30, y=30)
        self.cb.place(x=135, y=30)
        self.e.place(x=130, y=490)
        self.lb1.place(x=30, y=490)
        self.tt.place(x=30, y=60)
        # self.tt_tr.place(x=30, y=520)
        self.root.mainloop()  # 启动主页面

    def go(self, *arg):  # *arg是为了接受多个如同列表的参数，还有个**kwarg能接受如同字典的参数
        # 百度api
        self.APP_ID = '34493829'
        self.API_KEY = 'UrTKKniXTCfXc5Pf7k4RiqeG'
        self.SECRET_KEY = 'zQnsqCAqorLx8x2PPDhGVrZqLAoY058Y'
        self.client = AipSpeech(self.APP_ID, self.API_KEY, self.SECRET_KEY)  # 初始化端口建立连接
        if self.tt_tr.get("1.0", tk.END).strip():
            if self.cb.get() == '请选择-----':
                self.tt_tr.delete('1.0', 'end')  # 清除多行文本框的内容
            elif self.cb.get() == '甜美型':  # 获取下拉列表框的选项来设置不同的音，下同
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 3, 'pit': 4, 'per': 0})
                return self.res  # 返回音频信息 ，下同
            elif self.cb.get() == '萝莉型':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 2, 'pit': 3, 'per': 0})
                return self.res
            elif self.cb.get() == '大叔型':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 1})
                return self.res
            elif self.cb.get() == '精神小伙型':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 8, 'pit': 8, 'per': 1})
                return self.res
            elif self.cb.get() == '度逍遥':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 3})
                return self.res
            elif self.cb.get() == '度丫丫':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 4})
                return self.res
            elif self.cb.get() == '度小娇':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 5})
                return self.res
            elif self.cb.get() == '度米朵':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 103})
                return self.res
            elif self.cb.get() == '度米朵':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 103})
                return self.res
            elif self.cb.get() == '度博文':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 106})
                return self.res
            elif self.cb.get() == '度小童':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 110})
                return self.res
            elif self.cb.get() == '度小萌':
                self.res = self.client.synthesis(self.tt_tr.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 111})
                return self.res
        else:
            if self.cb.get() == '请选择-----':
                self.tt.delete('1.0', 'end')  # 清除多行文本框的内容
            elif self.cb.get() == '甜美型':  # 获取下拉列表框的选项来设置不同的音，下同
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 3, 'pit': 4, 'per': 0})
                return self.res  # 返回音频信息 ，下同
            elif self.cb.get() == '萝莉型':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 2, 'pit': 3, 'per': 0})
                return self.res
            elif self.cb.get() == '大叔型':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 1})
                return self.res
            elif self.cb.get() == '精神小伙型':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 8, 'pit': 8, 'per': 1})
                return self.res
            elif self.cb.get() == '度逍遥':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 3})
                return self.res
            elif self.cb.get() == '度丫丫':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 4})
                return self.res
            elif self.cb.get() == '度小娇':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 5})
                return self.res
            elif self.cb.get() == '度米朵':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 103})
                return self.res
            elif self.cb.get() == '度米朵':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 103})
                return self.res
            elif self.cb.get() == '度博文':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 106})
                return self.res
            elif self.cb.get() == '度小童':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 110})
                return self.res
            elif self.cb.get() == '度小萌':
                self.res = self.client.synthesis(self.tt.get('0.0', 'end'), 'zh', 1,
                                                 {'vol': 15, 'spd': 4, 'pit': 6, 'per': 111})
                return self.res

    def sc(self):
        if self.tt_tr.get("1.0", tk.END).strip():
            self.go()  # 引入go函数，不然下面的self.res 没法调用
            aa = self.tt_tr.get('0.0', 'end')  # 多行文本框内容为空
            ab = os.path.dirname(sys.argv[0]) + os.sep + self.e.get() + '.mp3'  # 文件名的地址，与程序同目录
            if len(aa) >= 1024:  # 判断长度是否超过1024
                messagebox.showerror(title='出错了！', message='^_^最多不超过1024个字节^_^')
            else:
                if not os.path.exists(ab):  # 如果没有这个文件则创建
                    with open(ab, 'wb+') as f:
                        f.write(self.res)  # 将音频信息写入到文件
                        # 生成结束给一个提示
                        messagebox.showinfo(title='完毕！', message='生成完毕，文件在程序目录下')
                else:
                    messagebox.showerror(title='出错了！', message='文件名已存在')  # 有这个文件就提示

        else:
            self.go()  # 引入go函数，不然下面的self.res 没法调用
            aa = self.tt.get('0.0', 'end')  # 多行文本框内容为空
            ab = os.path.dirname(sys.argv[0]) + os.sep + self.e.get() + '.mp3'  # 文件名的地址，与程序同目录
            if len(aa) >= 1024:  # 判断长度是否超过1024
                messagebox.showerror(title='出错了！', message='^_^最多不超过1024个字节^_^')
            else:
                if not os.path.exists(ab):  # 如果没有这个文件则创建
                    with open(ab, 'wb+') as f:
                        f.write(self.res)  # 将音频信息写入到文件
                        # 生成结束给一个提示
                        messagebox.showinfo(title='完毕！', message='生成完毕，文件在程序目录下')
                else:
                    messagebox.showerror(title='出错了！', message='文件名已存在')  # 有这个文件就提示


    def select_file(self):
        # 单个文件选择
        selected_file_path = filedialog.askopenfilename()  # 使用askopenfilename函数选择单个文件
        txt_file = self.tt.get("1.0", 'end-1c')
        t = open(selected_file_path, 'r+', encoding='utf-8')
        for id_names in t:
            self.tt.insert('insert', id_names)
        t.close()
        self.tt.window_create("insert")
        return self.tt
        # self.tt.insert('end', '\n')

    def getTransText(self):
        q = self.in_text.get("1.0", tk.END)
        fromLang = 'auto'
        toLang1 = 'auto'

        appid = '20230527001691554'  # APP ID
        salt = random.randint(32768, 65536)
        secretKey = '7Isy4YKD4SKOx3Zh5cCT'  # SecretKey

        sign = appid + q + str(salt) + secretKey
        m1 = hashlib.md5(sign.encode('utf-8'))
        sign = m1.hexdigest()

        myurl = '/api/trans/vip/translate'
        myurl = myurl + '?appid=' + appid + '&q=' + q + '&from=' + fromLang + '&to=' + toLang1 + '&salt=' + str(
            salt) + '&sign=' + sign
        url = "http://api.fanyi.baidu.com" + myurl

        url = url.encode('utf-8')
        res = requests.get(url)

        res = eval(res.text)
        return (res["trans_result"][0]['dst'])

    def translation(self):
        tr_content = self.getTransText()
        self.tt.insert('end', '\n')
        # self.tt.insert(tk.END, tr_content) # 按下“转译”按钮实现添加译文在文本框内
        # self.tt.delete('1.0', tk.END) # 按下“转译”按钮实现删除文本框内容
        self.tt_tr.insert(tk.END, tr_content) # 翻译的译文保存在隐藏的多行文本框中


play()